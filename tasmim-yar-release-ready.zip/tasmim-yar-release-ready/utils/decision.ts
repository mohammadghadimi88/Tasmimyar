export type Option = {
  id: string;
  label: string;
};

export type Criterion = {
  id: string;
  label: string;
  importance: number;
  scores: Record<string, number>;
};

export type Decision = {
  id: string;
  title: string;
  options: Option[];
  criteria: Criterion[];
  createdAt: string;
  updatedAt: string;
};

export type DecisionResult = {
  option: Option;
  total: number;
  score: number;
  rank: number;
};

export const makeId = () =>
  `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;

export const toPersianDigits = (value: string | number) =>
  String(value).replace(/\d/g, (digit) => '۰۱۲۳۴۵۶۷۸۹'[Number(digit)]);

export const formatDate = (date: string, language: 'fa' | 'en' = 'fa') => {
  try {
    return new Intl.DateTimeFormat(language === 'fa' ? 'fa-IR' : 'en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }).format(new Date(date));
  } catch {
    return toPersianDigits(new Date(date).toLocaleDateString('fa-IR'));
  }
};

export const calculateResults = (decision: Decision): DecisionResult[] => {
  const maxWeightedTotal =
    decision.criteria.reduce((sum, criterion) => sum + criterion.importance, 0) * 10;
  if (maxWeightedTotal === 0) {
    return decision.options.map((option, index) => ({
      option,
      total: 0,
      score: 0,
      rank: index + 1,
    }));
  }

  return decision.options
    .map((option) => {
      const total = decision.criteria.reduce(
        (sum, criterion) =>
          sum + criterion.importance * (criterion.scores[option.id] ?? 0),
        0,
      );
      return {
        option,
        total,
        score: Math.round((total / maxWeightedTotal) * 1000) / 100,
        rank: 0,
      };
    })
    .sort((a, b) => b.score - a.score)
    .map((result, index) => ({ ...result, rank: index + 1 }));
};

export const createSampleDecision = (language: 'fa' | 'en' = 'fa'): Decision => {
  const options = language === 'fa'
    ? [
        { id: makeId(), label: 'گوشی A' },
        { id: makeId(), label: 'گوشی B' },
        { id: makeId(), label: 'گوشی C' },
      ]
    : [
        { id: makeId(), label: 'Phone A' },
        { id: makeId(), label: 'Phone B' },
        { id: makeId(), label: 'Phone C' },
      ];
  const createCriterion = (label: string, importance: number, values: number[]): Criterion => ({
    id: makeId(),
    label,
    importance,
    scores: Object.fromEntries(options.map((option, index) => [option.id, values[index]])),
  });
  return {
    id: makeId(),
    title: language === 'fa' ? 'کدام گوشی را بخرم؟' : 'Which phone should I buy?',
    options,
    criteria: language === 'fa'
      ? [
          createCriterion('قیمت', 4, [8, 7, 6]),
          createCriterion('دوربین', 5, [7, 9, 8]),
          createCriterion('باتری', 3, [9, 7, 8]),
          createCriterion('عملکرد', 5, [8, 8, 9]),
        ]
      : [
          createCriterion('Price', 4, [8, 7, 6]),
          createCriterion('Camera', 5, [7, 9, 8]),
          createCriterion('Battery', 3, [9, 7, 8]),
          createCriterion('Performance', 5, [8, 8, 9]),
        ],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
};

export const createDraft = (): Decision => ({
  id: makeId(),
  title: '',
  options: [
    { id: makeId(), label: '' },
    { id: makeId(), label: '' },
  ],
  criteria: [],
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
});