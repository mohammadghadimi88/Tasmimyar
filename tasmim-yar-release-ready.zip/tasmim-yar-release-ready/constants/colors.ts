/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    text: '#18232e',
    tint: '#3157d5',
    background: '#f7f8fc',
    foreground: '#18232e',
    card: '#ffffff',
    cardForeground: '#18232e',
    primary: '#3157d5',
    primaryForeground: '#ffffff',
    secondary: '#eef1fb',
    secondaryForeground: '#3157d5',
    muted: '#edf0f5',
    mutedForeground: '#718096',
    accent: '#dff5f0',
    accentForeground: '#178b78',
    destructive: '#d94f68',
    destructiveForeground: '#ffffff',
    border: '#e1e6ef',
    input: '#d4dbe7',
    success: '#178b78',
    warning: '#e29a3b',
    scrim: 'rgba(24,35,46,0.38)',
  },
  dark: {
    text: '#f4f7fb',
    tint: '#8fa6ff',
    background: '#111722',
    foreground: '#f4f7fb',
    card: '#1b2432',
    cardForeground: '#f4f7fb',
    primary: '#8fa6ff',
    primaryForeground: '#111722',
    secondary: '#202c42',
    secondaryForeground: '#b9c6ff',
    muted: '#202a37',
    mutedForeground: '#9aa7b9',
    accent: '#143b3b',
    accentForeground: '#6cdbc5',
    destructive: '#ff7890',
    destructiveForeground: '#260d15',
    border: '#2b3748',
    input: '#3b485c',
    success: '#62d6c2',
    warning: '#f0b45b',
    scrim: 'rgba(0,0,0,0.58)',
  },
  radius: 18,
};

export default colors;
