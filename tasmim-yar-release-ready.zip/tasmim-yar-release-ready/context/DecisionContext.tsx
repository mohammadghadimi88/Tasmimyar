import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { useColorScheme } from 'react-native';
import { useLanguage } from '@/context/LanguageContext';
import colors from '@/constants/colors';
import {
  calculateResults,
  createDraft,
  createSampleDecision,
  Decision,
  Criterion,
  makeId,
  Option,
} from '@/utils/decision';

type ThemeMode = 'light' | 'dark' | 'system';
type DecisionContextValue = {
  decisions: Decision[];
  draft: Decision;
  activeDecision: Decision | null;
  isReady: boolean;
  themeMode: ThemeMode;
  palette: typeof colors.light;
  setThemeMode: (mode: ThemeMode) => void;
  startNewDecision: () => void;
  setTitle: (title: string) => void;
  setOptionLabel: (id: string, label: string) => void;
  addOption: () => void;
  removeOption: (id: string) => void;
  setCriterionLabel: (id: string, label: string) => void;
  setCriterionImportance: (id: string, importance: number) => void;
  addCriterion: () => void;
  removeCriterion: (id: string) => void;
  setScore: (criterionId: string, optionId: string, score: number) => void;
  saveDraft: () => Decision;
  openDecision: (decision: Decision) => void;
  deleteDecision: (id: string) => void;
};

const DECISIONS_KEY = '@tasmim-yar/decisions';
const THEME_KEY = '@tasmim-yar/theme';

const DecisionContext = createContext<DecisionContextValue | null>(null);

export function DecisionProvider({ children }: { children: React.ReactNode }) {
  const systemTheme = useColorScheme();
  const { language } = useLanguage();
  const [decisions, setDecisions] = useState<Decision[]>([]);
  const [draft, setDraft] = useState<Decision>(() => createDraft());
  const [activeDecision, setActiveDecision] = useState<Decision | null>(null);
  const [themeMode, setThemeModeState] = useState<ThemeMode>('system');
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        const [storedDecisions, storedTheme] = await Promise.all([
          AsyncStorage.getItem(DECISIONS_KEY),
          AsyncStorage.getItem(THEME_KEY),
        ]);
        const parsed = storedDecisions ? (JSON.parse(storedDecisions) as Decision[]) : [];
        setDecisions(parsed.length ? parsed : [createSampleDecision(language)]);
        if (storedTheme === 'light' || storedTheme === 'dark' || storedTheme === 'system') {
          setThemeModeState(storedTheme);
        }
      } finally {
        setIsReady(true);
      }
    };
    void load();
  }, [language]);

  useEffect(() => {
    if (isReady) void AsyncStorage.setItem(DECISIONS_KEY, JSON.stringify(decisions));
  }, [decisions, isReady]);

  const setThemeMode = (mode: ThemeMode) => {
    setThemeModeState(mode);
    void AsyncStorage.setItem(THEME_KEY, mode);
  };

  const updateDraft = (updater: (current: Decision) => Decision) =>
    setDraft((current) => ({ ...updater(current), updatedAt: new Date().toISOString() }));

  const setTitle = (title: string) => updateDraft((current) => ({ ...current, title }));
  const setOptionLabel = (id: string, label: string) =>
    updateDraft((current) => ({
      ...current,
      options: current.options.map((option) => (option.id === id ? { ...option, label } : option)),
    }));
  const addOption = () =>
    updateDraft((current) =>
      current.options.length >= 6
        ? current
        : { ...current, options: [...current.options, { id: makeId(), label: '' }] },
    );
  const removeOption = (id: string) =>
    updateDraft((current) => ({
      ...current,
      options: current.options.filter((option) => option.id !== id),
      criteria: current.criteria.map((criterion) => {
        const scores = { ...criterion.scores };
        delete scores[id];
        return { ...criterion, scores };
      }),
    }));
  const setCriterionLabel = (id: string, label: string) =>
    updateDraft((current) => ({
      ...current,
      criteria: current.criteria.map((criterion) =>
        criterion.id === id ? { ...criterion, label } : criterion,
      ),
    }));
  const setCriterionImportance = (id: string, importance: number) =>
    updateDraft((current) => ({
      ...current,
      criteria: current.criteria.map((criterion) =>
        criterion.id === id ? { ...criterion, importance } : criterion,
      ),
    }));
  const addCriterion = () =>
    updateDraft((current) =>
      current.criteria.length >= 8
        ? current
        : {
            ...current,
            criteria: [
              ...current.criteria,
              { id: makeId(), label: '', importance: 3, scores: {} },
            ],
          },
    );
  const removeCriterion = (id: string) =>
    updateDraft((current) => ({
      ...current,
      criteria: current.criteria.filter((criterion) => criterion.id !== id),
    }));
  const setScore = (criterionId: string, optionId: string, score: number) =>
    updateDraft((current) => ({
      ...current,
      criteria: current.criteria.map((criterion) =>
        criterion.id === criterionId
          ? { ...criterion, scores: { ...criterion.scores, [optionId]: score } }
          : criterion,
      ),
    }));

  const startNewDecision = () => {
    setDraft(createDraft());
    setActiveDecision(null);
  };

  const saveDraft = () => {
    const finalDecision = { ...draft, updatedAt: new Date().toISOString() };
    setDecisions((current) => {
      const exists = current.some((decision) => decision.id === finalDecision.id);
      return exists
        ? current.map((decision) => (decision.id === finalDecision.id ? finalDecision : decision))
        : [finalDecision, ...current];
    });
    setDraft(finalDecision);
    setActiveDecision(finalDecision);
    return finalDecision;
  };

  const openDecision = (decision: Decision) => {
    setDraft(decision);
    setActiveDecision(decision);
  };

  const deleteDecision = (id: string) =>
    setDecisions((current) => current.filter((decision) => decision.id !== id));

  const palette = useMemo(() => {
    const resolvedMode: 'light' | 'dark' =
      themeMode === 'system' ? (systemTheme === 'dark' ? 'dark' : 'light') : themeMode;
    return colors[resolvedMode];
  }, [systemTheme, themeMode]);

  const value: DecisionContextValue = {
    decisions,
    draft,
    activeDecision,
    isReady,
    themeMode,
    palette,
    setThemeMode,
    startNewDecision,
    setTitle,
    setOptionLabel,
    addOption,
    removeOption,
    setCriterionLabel,
    setCriterionImportance,
    addCriterion,
    removeCriterion,
    setScore,
    saveDraft,
    openDecision,
    deleteDecision,
  };

  return <DecisionContext.Provider value={value}>{children}</DecisionContext.Provider>;
}

export function useDecisionStore() {
  const value = useContext(DecisionContext);
  if (!value) throw new Error('useDecisionStore must be used inside DecisionProvider');
  return value;
}

export { calculateResults };