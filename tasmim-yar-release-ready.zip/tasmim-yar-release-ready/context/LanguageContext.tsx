import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';

export type Language = 'fa' | 'en';

const LANGUAGE_KEY = '@tasmim-yar/language';

const translations = {
  fa: {
    appName: 'تصمیم‌یار',
    appTagline: 'شفاف‌تر انتخاب کن',
    homeEyebrow: 'فضایی برای فکر کردن',
    homeTitle: 'به جای حدس زدن،\nتصمیم‌هایت را روشن‌تر ببین.',
    homeBody: 'معیارهایت را مشخص کن، وزن بده و با خیال راحت مقایسه کن.',
    newDecision: 'تصمیم جدید',
    recentDecisions: 'تصمیم‌های اخیر',
    savedDecisions: 'تصمیم ذخیره شده',
    viewAll: 'مشاهده همه',
    optionsCount: 'گزینه',
    resultReady: 'نتیجه آماده است',
    noDecision: 'هنوز تصمیمی ثبت نکرده‌ای.',
    noDecisionBody: 'اولین تصمیم را بساز و انتخاب‌هایت را روشن‌تر ببین.',
    firstDecision: 'اولین تصمیم را بساز',
    archive: 'آرشیو شخصی تو',
    myDecisions: 'تصمیم‌های من',
    archiveBody: 'تصمیم‌هایت را نگه دار و هر وقت خواستی دوباره مرورشان کن.',
    archiveEmpty: 'آرشیوت هنوز خالی است',
    archiveEmptyBody: 'بعد از ذخیره اولین تصمیم، اینجا نمایش داده می‌شود.',
    deleteDecision: 'حذف تصمیم',
    deleteConfirm: 'آیا از حذف این تصمیم مطمئنی؟',
    cancel: 'انصراف',
    delete: 'حذف',
    settingsOverline: 'شخصی‌سازی',
    settings: 'تنظیمات',
    appearance: 'حالت نمایش',
    appearanceBody: 'ظاهر برنامه را با حال و هوایت هماهنگ کن.',
    light: 'روشن',
    dark: 'تاریک',
    system: 'سیستم',
    about: 'درباره تصمیم‌یار',
    aboutBody: 'برای تصمیم‌های روشن‌تر، بدون حدس زدن.',
    version: 'نسخه برنامه',
    language: 'زبان',
    persian: 'فارسی',
    english: 'English',
    newDecisionTitle: 'تصمیم جدید',
    step1: '۱ از ۳',
    start: 'از کجا شروع کنیم؟',
    startBody: 'موضوع تصمیم و گزینه‌هایی که می‌خواهی مقایسه کنی را وارد کن.',
    decisionTopic: 'موضوع تصمیم',
    topicPlaceholder: 'مثلاً کدام گوشی را بخرم؟',
    options: 'گزینه‌ها',
    addOptions: 'بین ۲ تا ۶ گزینه اضافه کن.',
    addOption: 'افزودن گزینه',
    next: 'مرحله بعد',
    step2: '۲ از ۳',
    criteriaTitle: 'معیارهای تصمیم',
    criteriaQuestion: 'چه چیزهایی برایت مهم است؟',
    criteriaBody: 'به هر معیار از ۱ تا ۵ اهمیت بده تا نظر تو در نتیجه پررنگ‌تر باشد.',
    criteriaTip: 'مثلاً قیمت، کیفیت یا دوام را اضافه کن.',
    newCriterion: 'معیار جدید',
    criterionNameError: 'نام معیار را وارد کن.',
    importance: 'اهمیت',
    addCriterion: 'افزودن معیار',
    scoring: 'امتیازدهی',
    step3: '۳ از ۳',
    scoringTitle: 'امتیازدهی',
    currentCriterion: 'معیار فعلی',
    scoreOptions: 'به گزینه‌ها امتیاز بده',
    scoringInstruction: 'به هر گزینه از ۱ (کمترین) تا ۱۰ (بیشترین) امتیاز بده.',
    notSelected: 'انتخاب نشده',
    nextCriterion: 'معیار بعدی',
    seeResult: 'مشاهده نتیجه',
    scoreAll: 'برای همه گزینه‌ها امتیاز انتخاب کن.',
    resultTitle: 'نتیجه تصمیم',
    resultSummary: 'جمع‌بندی انتخاب تو',
    basedOn: 'بر اساس',
    criteria: 'معیار',
    highestScore: 'بیشترین امتیاز',
    outOf10: 'از ۱۰',
    resultNote: 'بر اساس معیارها و امتیازهایی که خودت وارد کرده‌ای',
    compareOptions: 'مقایسه گزینه‌ها',
    neutralResult: 'این نتیجه فقط بازتاب معیارها و امتیازهای توست؛ تصمیم نهایی همیشه با خودت است.',
    saveDecision: 'ذخیره تصمیم',
    saved: 'ذخیره شد',
    decisionSaved: 'تصمیم ذخیره شد',
    decisionSavedBody: 'این تصمیم در دستگاهت ذخیره شد و هر زمان می‌توانی به آن برگردی.',
    optionRequired: 'حداقل دو گزینه لازم است.',
    titleRequired: 'موضوع تصمیم را وارد کن.',
    languageChange: 'زبان را انتخاب کن',
  },
  en: {
    appName: 'DecisionYar',
    appTagline: 'Choose with clarity',
    homeEyebrow: 'A space to think',
    homeTitle: 'Instead of guessing,\nsee your decisions clearly.',
    homeBody: 'Define your criteria, set their importance, and compare with confidence.',
    newDecision: 'New Decision',
    recentDecisions: 'Recent Decisions',
    savedDecisions: 'saved decisions',
    viewAll: 'View All',
    optionsCount: 'options',
    resultReady: 'Result ready',
    noDecision: 'You have no saved decisions yet.',
    noDecisionBody: 'Create your first decision and see your options more clearly.',
    firstDecision: 'Create First Decision',
    archive: 'Your personal archive',
    myDecisions: 'My Decisions',
    archiveBody: 'Keep your decisions and review them whenever you want.',
    archiveEmpty: 'Your archive is empty',
    archiveEmptyBody: 'Your saved decisions will appear here.',
    deleteDecision: 'Delete Decision',
    deleteConfirm: 'Are you sure you want to delete this decision?',
    cancel: 'Cancel',
    delete: 'Delete',
    settingsOverline: 'PERSONALIZE',
    settings: 'Settings',
    appearance: 'Appearance',
    appearanceBody: 'Match the app appearance to your preference.',
    light: 'Light',
    dark: 'Dark',
    system: 'System',
    about: 'About DecisionYar',
    aboutBody: 'For clearer decisions, without guessing.',
    version: 'App version',
    language: 'Language',
    persian: 'فارسی',
    english: 'English',
    newDecisionTitle: 'New Decision',
    step1: '1 of 3',
    start: 'Where do we start?',
    startBody: 'Enter the decision topic and the options you want to compare.',
    decisionTopic: 'Decision topic',
    topicPlaceholder: 'e.g. Which phone should I buy?',
    options: 'Options',
    addOptions: 'Add 2 to 6 options.',
    addOption: 'Add Option',
    next: 'Next',
    step2: '2 of 3',
    criteriaTitle: 'Decision Criteria',
    criteriaQuestion: 'What matters to you?',
    criteriaBody: 'Rate each criterion from 1 to 5 so its importance affects the result.',
    criteriaTip: 'For example: price, quality, or durability.',
    newCriterion: 'New criterion',
    criterionNameError: 'Enter a criterion name.',
    importance: 'Importance',
    addCriterion: 'Add Criterion',
    scoring: 'Scoring',
    step3: '3 of 3',
    scoringTitle: 'Scoring',
    currentCriterion: 'Current criterion',
    scoreOptions: 'Score the options',
    scoringInstruction: 'Rate each option from 1 (lowest) to 10 (highest).',
    notSelected: 'Not selected',
    nextCriterion: 'Next Criterion',
    seeResult: 'See Results',
    scoreAll: 'Choose a score for every option.',
    resultTitle: 'Decision Result',
    resultSummary: 'Your decision summary',
    basedOn: 'Based on',
    criteria: 'criteria',
    highestScore: 'Highest score',
    outOf10: 'out of 10',
    resultNote: 'Based on the criteria and scores you entered',
    compareOptions: 'Compare Options',
    neutralResult: 'This result only reflects your criteria and scores; the final decision is always yours.',
    saveDecision: 'Save Decision',
    saved: 'Saved',
    decisionSaved: 'Decision saved',
    decisionSavedBody: 'This decision was saved on your device and you can return to it anytime.',
    optionRequired: 'At least two options are required.',
    titleRequired: 'Enter a decision topic.',
    languageChange: 'Choose language',
  },
} as const;

type TranslationKey = keyof typeof translations.en;
type LanguageContextValue = {
  language: Language;
  isRTL: boolean;
  t: (key: TranslationKey) => string;
  setLanguage: (language: Language) => void;
};

const LanguageContext = createContext<LanguageContextValue | null>(null);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<Language>('fa');

  useEffect(() => {
    AsyncStorage.getItem(LANGUAGE_KEY).then((stored) => {
      if (stored === 'fa' || stored === 'en') setLanguageState(stored);
    });
  }, []);

  const setLanguage = (next: Language) => {
    setLanguageState(next);
    void AsyncStorage.setItem(LANGUAGE_KEY, next);
  };

  const value = useMemo(() => ({
    language,
    isRTL: language === 'fa',
    t: (key: TranslationKey) => translations[language][key] ?? translations.en[key],
    setLanguage,
  }), [language]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const value = useContext(LanguageContext);
  if (!value) throw new Error('useLanguage must be used inside LanguageProvider');
  return value;
}
