# DecisionYar release-ready Expo project

This folder is the mobile Expo/React Native app. It has:
- Persian RTL + English LTR language switch
- Vazirmatn font for Persian UI
- Local persistence with AsyncStorage
- Android and iOS identifiers
- EAS Build profiles
- Production Android AAB and iOS IPA support
- Correct weighted score displayed on a 0–10 scale

## 1) Install dependencies
From this folder:
```bash
pnpm install
pnpm exec expo doctor
```

If you use npm instead, remove `pnpm-lock.yaml` if present and use:
```bash
npm install
npx expo doctor
```

## 2) Login to Expo
```bash
npx eas login
npx eas init
```
`eas init` will attach this project to your Expo account and may add an EAS project ID.

## 3) Testable Android APK
```bash
npx eas build --platform android --profile preview
```
Install the generated APK on an Android phone.

## 4) Google Play production AAB
```bash
npx eas build --platform android --profile production
```
Upload the resulting `.aab` to Google Play Console.

## 5) iOS production build
```bash
npx eas build --platform ios --profile production
```
Then upload it:
```bash
npx eas submit --platform ios
```

## 6) Android submission
You can submit with EAS after setting up the Google Play service account:
```bash
npx eas submit --platform android
```

For a first release, manual Play Console setup is still recommended so the app listing, testing track, Data Safety, content rating, and production-access requirements are completed correctly.

## Important
The package/bundle identifiers are placeholders:
- Android: `com.tasmimyar.app`
- iOS: `com.tasmimyar.app`

If either identifier is already registered, change it in `app.json` before the first production build.

The store listing, privacy policy, screenshot checklist, and descriptions are in `store/`.
