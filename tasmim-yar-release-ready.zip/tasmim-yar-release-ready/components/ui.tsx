import { Feather } from '@expo/vector-icons';
import React from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  TextInputProps,
  View,
} from 'react-native';
import { useDecisionStore } from '@/context/DecisionContext';
import { useLanguage } from '@/context/LanguageContext';

export function AppText({
  children, style, muted = false, bold = false, numberOfLines,
}: {
  children: React.ReactNode; style?: object; muted?: boolean; bold?: boolean; numberOfLines?: number;
}) {
  const { palette } = useDecisionStore();
  const { isRTL } = useLanguage();
  return (
    <Text
      style={[
        { color: muted ? palette.mutedForeground : palette.foreground, textAlign: isRTL ? 'right' : 'left', writingDirection: isRTL ? 'rtl' : 'ltr' },
        styles.text,
        bold && styles.bold,
        style,
      ]}
      numberOfLines={numberOfLines}
    >{children}</Text>
  );
}

export function Screen({
  children,
  scroll = false,
  contentStyle,
}: {
  children: React.ReactNode;
  scroll?: boolean;
  contentStyle?: object;
}) {
  const { palette } = useDecisionStore();
  const Wrapper = scroll ? require('react-native').ScrollView : View;
  return (
    <Wrapper
      style={[styles.screen, { backgroundColor: palette.background }]}
      contentContainerStyle={scroll ? [styles.screenContent, contentStyle] : undefined}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
    >
      {children}
    </Wrapper>
  );
}

export function TopBar({ title, onBack, right }: {
  title: string; onBack?: () => void; right?: React.ReactNode;
}) {
  const { palette } = useDecisionStore();
  const { isRTL } = useLanguage();
  return (
    <View style={[styles.topBar, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
      {onBack ? (
        <Pressable onPress={onBack} style={({ pressed }) => [
          styles.iconButton, { backgroundColor: palette.card, opacity: pressed ? 0.65 : 1 },
        ]} hitSlop={10}>
          <Feather name={isRTL ? 'arrow-right' : 'arrow-left'} size={21} color={palette.foreground} />
        </Pressable>
      ) : <View style={styles.iconButton} />}
      <AppText style={styles.topTitle} bold>{title}</AppText>
      {right ?? <View style={styles.iconButton} />}
    </View>
  );
}

export function PrimaryButton({
  label,
  onPress,
  disabled = false,
  loading = false,
  secondary = false,
  icon,
}: {
  label: string;
  onPress: () => void;
  disabled?: boolean;
  loading?: boolean;
  secondary?: boolean;
  icon?: keyof typeof Feather.glyphMap;
}) {
  const { palette } = useDecisionStore();
  const { isRTL } = useLanguage();
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      style={({ pressed }) => [
        styles.primaryButton,
        { flexDirection: isRTL ? 'row-reverse' : 'row',
          backgroundColor: secondary ? palette.secondary : palette.primary,
          borderColor: secondary ? palette.border : palette.primary,
          opacity: disabled || loading ? 0.45 : pressed ? 0.78 : 1,
        },
      ]}
    >
      {loading ? (
        <ActivityIndicator color={secondary ? palette.secondaryForeground : palette.primaryForeground} />
      ) : (
        <>
          {icon ? (
            <Feather
              name={icon}
              size={18}
              color={secondary ? palette.secondaryForeground : palette.primaryForeground}
            />
          ) : null}
          <Text
            style={[
              styles.buttonText,
              { color: secondary ? palette.secondaryForeground : palette.primaryForeground },
            ]}
          >
            {label}
          </Text>
        </>
      )}
    </Pressable>
  );
}

export function Field({
  label,
  error,
  ...props
}: TextInputProps & { label?: string; error?: string }) {
  const { palette } = useDecisionStore();
  const { isRTL } = useLanguage();
  return (
    <View style={styles.fieldWrap}>
      {label ? <AppText style={styles.fieldLabel} bold>{label}</AppText> : null}
      <TextInput
        {...props}
        placeholderTextColor={palette.mutedForeground}
        style={[
          styles.input,
          { color: palette.foreground, backgroundColor: palette.card, borderColor: error ? palette.destructive : palette.input },
          props.style,
        ]}
        textAlign={isRTL ? 'right' : 'left'}
        writingDirection={isRTL ? 'rtl' : 'ltr'}
        selectionColor={palette.primary}
      />
      {error ? <AppText style={{ color: palette.destructive, fontSize: 12 }}>{error}</AppText> : null}
    </View>
  );
}

export function SectionTitle({
  title,
  caption,
  action,
  onAction,
}: {
  title: string;
  caption?: string;
  action?: string;
  onAction?: () => void;
}) {
  const { palette } = useDecisionStore();
  const { isRTL } = useLanguage();
  return (
    <View style={[styles.sectionHeader, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
      <View style={styles.sectionCopy}>
        <AppText style={styles.sectionTitle} bold>{title}</AppText>
        {caption ? <AppText muted style={styles.caption}>{caption}</AppText> : null}
      </View>
      {action && onAction ? (
        <Pressable onPress={onAction} hitSlop={8}>
          <AppText style={{ color: palette.primary, fontSize: 13 }} bold>{action}</AppText>
        </Pressable>
      ) : null}
    </View>
  );
}

export const styles = StyleSheet.create({
  screen: { flex: 1 },
  screenContent: { paddingHorizontal: 20, paddingBottom: 32 },
  text: { fontFamily: 'Vazirmatn_400Regular', fontSize: 15 },
  bold: { fontFamily: 'Vazirmatn_700Bold' },
  topBar: { minHeight: 58, alignItems: 'center', justifyContent: 'space-between', flexDirection: 'row-reverse', marginBottom: 16 },
  topTitle: { fontSize: 20, textAlign: 'center', flex: 1 },
  iconButton: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  primaryButton: { minHeight: 52, borderRadius: 17, borderWidth: 1, paddingHorizontal: 20, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 8 },
  buttonText: { fontFamily: 'Vazirmatn_700Bold', fontSize: 15 },
  fieldWrap: { gap: 8, marginBottom: 18 },
  fieldLabel: { fontSize: 14 },
  input: { height: 52, borderRadius: 15, borderWidth: 1, paddingHorizontal: 16, fontFamily: 'Vazirmatn_400Regular', fontSize: 15 },
  sectionHeader: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  sectionCopy: { gap: 3 },
  sectionTitle: { fontSize: 18 },
  caption: { fontSize: 12 },
});