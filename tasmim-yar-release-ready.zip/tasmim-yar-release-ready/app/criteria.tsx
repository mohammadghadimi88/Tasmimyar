import { Feather } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { AppText, Field, PrimaryButton, TopBar, styles as ui } from '@/components/ui';
import { useDecisionStore } from '@/context/DecisionContext';
import { useLanguage } from '@/context/LanguageContext';

export default function CriteriaScreen(){
 const router=useRouter();const insets=useSafeAreaInsets();const {draft,palette,setCriterionLabel,setCriterionImportance,addCriterion,removeCriterion}=useDecisionStore();const {t,isRTL}=useLanguage();const [submitted,setSubmitted]=useState(false);
 const valid=draft.criteria.filter(c=>c.label.trim());const next=()=>{setSubmitted(true);if(!valid.length||draft.criteria.some(c=>!c.label.trim()))return;router.push('/scoring');};
 const placeholders=isRTL?['قیمت','کیفیت','راحتی','سرعت','دوام','ظاهر']:['Price','Quality','Comfort','Speed','Durability','Design'];
 return <View style={[s.root,{backgroundColor:palette.background}]}>
  <KeyboardAwareScrollViewCompat contentContainerStyle={[ui.screenContent,{paddingTop:insets.top+8,paddingBottom:124}]} showsVerticalScrollIndicator={false}>
   <TopBar title={t('criteriaTitle')} onBack={()=>router.back()}/>
   <View style={[s.intro,{alignItems:isRTL?'flex-end':'flex-start'}]}><View style={[s.stepBadge,{backgroundColor:palette.secondary}]}><AppText style={[s.stepText,{color:palette.secondaryForeground}]} bold>{t('step2')}</AppText></View><AppText style={s.heading} bold>{t('criteriaQuestion')}</AppText><AppText muted style={s.subheading}>{t('criteriaBody')}</AppText></View>
   {!draft.criteria.length?<View style={[s.tip,{backgroundColor:palette.accent,flexDirection:isRTL?'row-reverse':'row'}]}><Feather name="info" size={17} color={palette.accentForeground}/><AppText style={[s.tipText,{color:palette.accentForeground}]}>{t('criteriaTip')}</AppText></View>:null}
   {draft.criteria.map((criterion,index)=><View key={criterion.id} style={[s.card,{backgroundColor:palette.card,borderColor:palette.border}]}>
    <View style={[s.top,{flexDirection:isRTL?'row-reverse':'row'}]}><View style={[s.number,{backgroundColor:palette.secondary}]}><AppText style={[s.numberText,{color:palette.secondaryForeground}]} bold>{index+1}</AppText></View><View style={{flex:1}}><Field placeholder={placeholders[index]??t('newCriterion')} value={criterion.label} onChangeText={v=>setCriterionLabel(criterion.id,v)} error={submitted&&!criterion.label.trim()?t('criterionNameError'):undefined}/></View><Pressable onPress={()=>removeCriterion(criterion.id)} hitSlop={8} style={s.delete}><Feather name="trash-2" size={17} color={palette.destructive}/></Pressable></View>
    <View style={[s.importanceRow,{flexDirection:isRTL?'row-reverse':'row'}]}><AppText muted style={s.importanceLabel}>{t('importance')}</AppText><View style={s.stars}>{[1,2,3,4,5].map(v=><Pressable key={v} onPress={()=>setCriterionImportance(criterion.id,v)} hitSlop={4}><Feather name="star" size={22} color={v<=criterion.importance?palette.warning:palette.border}/></Pressable>)}</View><AppText style={{color:palette.warning,fontSize:12}} bold>{criterion.importance} / 5</AppText></View>
   </View>)}
   <Pressable onPress={addCriterion} disabled={draft.criteria.length>=8} style={({pressed})=>[s.add,{borderColor:palette.border,opacity:draft.criteria.length>=8?.4:pressed?.65:1,flexDirection:isRTL?'row-reverse':'row'}]}><Feather name="plus" size={17} color={palette.primary}/><AppText style={{color:palette.primary,fontSize:13}} bold>{t('addCriterion')}</AppText></Pressable>
  </KeyboardAwareScrollViewCompat>
  <View style={[s.footer,{backgroundColor:palette.background,paddingBottom:insets.bottom+12}]}><PrimaryButton label={t('scoring')} onPress={next} icon={isRTL?'arrow-left':'arrow-right'}/></View>
 </View>;
}
const s=StyleSheet.create({root:{flex:1},intro:{marginBottom:22},stepBadge:{paddingHorizontal:10,paddingVertical:5,borderRadius:9,marginBottom:12},stepText:{fontSize:11},heading:{fontSize:22,marginBottom:7},subheading:{fontSize:13,lineHeight:22},tip:{alignItems:'center',gap:8,padding:13,borderRadius:14,marginBottom:14},tipText:{fontSize:12,flex:1},card:{borderWidth:1,borderRadius:19,padding:14,marginBottom:12},top:{alignItems:'center',gap:8},number:{width:28,height:28,borderRadius:10,alignItems:'center',justifyContent:'center'},numberText:{fontSize:12},delete:{width:28,alignItems:'center'},importanceRow:{alignItems:'center',justifyContent:'space-between',marginTop:-3},importanceLabel:{fontSize:12},stars:{flexDirection:'row',gap:2},add:{height:47,borderWidth:1,borderStyle:'dashed',borderRadius:14,alignItems:'center',justifyContent:'center',gap:7,marginTop:2},footer:{position:'absolute',bottom:0,left:0,right:0,paddingHorizontal:20,paddingTop:10}});
