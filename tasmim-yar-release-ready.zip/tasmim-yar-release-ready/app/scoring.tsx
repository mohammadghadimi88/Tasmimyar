import { Feather } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppText, PrimaryButton, Screen, TopBar } from '@/components/ui';
import { useDecisionStore } from '@/context/DecisionContext';
import { useLanguage } from '@/context/LanguageContext';

export default function ScoringScreen(){
 const router=useRouter();const insets=useSafeAreaInsets();const {draft,palette,setScore}=useDecisionStore();const {t,isRTL}=useLanguage();const [criterionIndex,setCriterionIndex]=useState(0);const [error,setError]=useState('');
 const criterion=draft.criteria[criterionIndex];const progress=useMemo(()=> (criterionIndex+1)/Math.max(draft.criteria.length,1),[criterionIndex,draft.criteria.length]);if(!criterion)return null;
 const next=()=>{const incomplete=draft.options.some(o=>!criterion.scores[o.id]);if(incomplete){setError(t('scoreAll'));return;}setError('');if(criterionIndex<draft.criteria.length-1)setCriterionIndex(v=>v+1);else router.push('/result');};
 return <Screen scroll contentStyle={{paddingTop:insets.top+8,paddingBottom:insets.bottom+24}}>
  <TopBar title={t('scoring')} onBack={()=>router.back()}/>
  <View style={[s.progressHeader,{flexDirection:isRTL?'row-reverse':'row'}]}><View style={{alignItems:isRTL?'flex-end':'flex-start'}}><AppText muted style={s.progressLabel}>{t('criteria')} {criterionIndex+1} {isRTL?'از':'of'} {draft.criteria.length}</AppText><AppText style={s.heading} bold>{t('scoreOptions')}</AppText></View><View style={[s.circle,{borderColor:palette.primary}]}><AppText style={{color:palette.primary,fontSize:13}} bold>{Math.round(progress*100)}%</AppText></View></View>
  <View style={[s.track,{backgroundColor:palette.muted}]}><View style={[s.fill,{backgroundColor:palette.primary,width:`${progress*100}%`}]}/></View>
  <View style={[s.banner,{backgroundColor:palette.secondary,flexDirection:isRTL?'row-reverse':'row'}]}><Feather name="sliders" size={18} color={palette.secondaryForeground}/><View style={[s.bannerCopy,{alignItems:isRTL?'flex-end':'flex-start'}]}><AppText muted style={s.bannerLabel}>{t('currentCriterion')}</AppText><AppText style={[s.bannerTitle,{color:palette.secondaryForeground}]} bold>{criterion.label}</AppText></View><View style={s.weight}><AppText style={{color:palette.warning,fontSize:12}} bold>{t('importance')} {criterion.importance}/5</AppText></View></View>
  <AppText muted style={s.instruction}>{t('scoringInstruction')}</AppText>
  <View style={s.list}>{draft.options.map(option=>{const selected=criterion.scores[option.id]??0;return <View key={option.id} style={[s.card,{backgroundColor:palette.card,borderColor:palette.border}]}>
   <View style={[s.optionNameRow,{flexDirection:isRTL?'row-reverse':'row'}]}><View style={[s.optionIcon,{backgroundColor:palette.accent}]}><AppText style={{color:palette.accentForeground,fontSize:13}} bold>{option.label.slice(0,1)||'?'}</AppText></View><AppText style={s.optionName} bold>{option.label}</AppText><View style={{flex:1}}/><AppText style={[s.scoreValue,{color:selected?palette.primary:palette.mutedForeground}]} bold>{selected?`${selected} / 10`:t('notSelected')}</AppText></View>
   <View style={[s.grid,{flexDirection:isRTL?'row-reverse':'row'}]}>{[1,2,3,4,5,6,7,8,9,10].map(score=><Pressable key={score} onPress={()=>setScore(criterion.id,option.id,score)} style={({pressed})=>[s.scoreButton,{backgroundColor:score===selected?palette.primary:palette.muted,opacity:pressed?.7:1}]}><AppText style={{color:score===selected?palette.primaryForeground:palette.mutedForeground,fontSize:12}} bold>{score}</AppText></Pressable>)}</View>
  </View>})}</View>
  {error?<AppText style={{color:palette.destructive,fontSize:12,marginBottom:12}}>{error}</AppText>:null}
  <PrimaryButton label={criterionIndex===draft.criteria.length-1?t('seeResult'):t('nextCriterion')} onPress={next} icon={isRTL?'arrow-left':'arrow-right'}/>
 </Screen>;
}
const s=StyleSheet.create({progressHeader:{alignItems:'center',justifyContent:'space-between',marginBottom:14},progressLabel:{fontSize:12,marginBottom:4},heading:{fontSize:22},circle:{width:52,height:52,borderWidth:4,borderRadius:28,alignItems:'center',justifyContent:'center'},track:{height:5,borderRadius:5,overflow:'hidden',marginBottom:20},fill:{height:'100%',borderRadius:5},banner:{alignItems:'center',borderRadius:18,padding:15,gap:10,marginBottom:13},bannerCopy:{},bannerLabel:{fontSize:11,marginBottom:2},bannerTitle:{fontSize:17},weight:{marginLeft:'auto',paddingHorizontal:8,paddingVertical:5,borderRadius:8,backgroundColor:'rgba(255,255,255,0.55)'},instruction:{fontSize:12,marginBottom:14},list:{gap:12,marginBottom:16},card:{borderWidth:1,borderRadius:19,padding:14},optionNameRow:{alignItems:'center',gap:8,marginBottom:14},optionIcon:{width:30,height:30,borderRadius:10,alignItems:'center',justifyContent:'center'},optionName:{fontSize:14},scoreValue:{fontSize:11},grid:{justifyContent:'space-between',gap:4},scoreButton:{flex:1,height:35,borderRadius:9,alignItems:'center',justifyContent:'center'}});
