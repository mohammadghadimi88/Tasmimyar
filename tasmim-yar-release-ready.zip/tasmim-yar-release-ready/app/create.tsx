import { Feather } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { AppText, Field, PrimaryButton, TopBar, styles as ui } from '@/components/ui';
import { useDecisionStore } from '@/context/DecisionContext';
import { useLanguage } from '@/context/LanguageContext';

export default function CreateDecisionScreen() {
  const router=useRouter(); const insets=useSafeAreaInsets();
  const {draft,palette,setTitle,setOptionLabel,addOption,removeOption}=useDecisionStore();
  const {t,isRTL}=useLanguage(); const [submitted,setSubmitted]=useState(false);
  const validOptions=draft.options.filter(o=>o.label.trim());
  const titleError=submitted&&!draft.title.trim()?t('titleRequired'):undefined;
  const optionError=submitted&&validOptions.length<2?t('optionRequired'):undefined;
  const next=()=>{setSubmitted(true);if(!draft.title.trim()||validOptions.length<2||draft.options.some(o=>!o.label.trim()))return;router.push('/criteria');};

  return <View style={[s.root,{backgroundColor:palette.background}]}>
    <KeyboardAwareScrollViewCompat contentContainerStyle={[ui.screenContent,{paddingTop:insets.top+8,paddingBottom:124}]} showsVerticalScrollIndicator={false}>
      <TopBar title={t('newDecisionTitle')} onBack={()=>router.back()}/>
      <View style={[s.intro,{alignItems:isRTL?'flex-end':'flex-start'}]}>
        <View style={[s.stepBadge,{backgroundColor:palette.secondary}]}><AppText style={[s.stepText,{color:palette.secondaryForeground}]} bold>{t('step1')}</AppText></View>
        <AppText style={s.heading} bold>{t('start')}</AppText><AppText muted style={s.subheading}>{t('startBody')}</AppText>
      </View>
      <Field label={t('decisionTopic')} placeholder={t('topicPlaceholder')} value={draft.title} onChangeText={setTitle} error={titleError} autoFocus returnKeyType="done"/>
      <View style={s.section}>
        <View style={[s.sectionHeader,{flexDirection:isRTL?'row-reverse':'row'}]}>
          <View style={{alignItems:isRTL?'flex-end':'flex-start'}}><AppText style={s.sectionTitle} bold>{t('options')}</AppText><AppText muted style={s.sectionHint}>{t('addOptions')}</AppText></View>
          <View style={[s.countBadge,{backgroundColor:palette.muted}]}><AppText muted style={s.countText}>{draft.options.length} / 6</AppText></View>
        </View>
        {draft.options.map((option,index)=><View key={option.id} style={[s.optionRow,{flexDirection:isRTL?'row-reverse':'row'}]}>
          <View style={[s.number,{backgroundColor:palette.secondary}]}><AppText style={[s.numberText,{color:palette.secondaryForeground}]} bold>{index+1}</AppText></View>
          <View style={{flex:1}}><Field placeholder={`${t('options')} ${index+1}`} value={option.label} onChangeText={v=>setOptionLabel(option.id,v)}/></View>
          {draft.options.length>2?<Pressable onPress={()=>removeOption(option.id)} style={s.deleteButton} hitSlop={8}><Feather name="trash-2" size={17} color={palette.destructive}/></Pressable>:null}
        </View>)}
        {optionError?<AppText style={{color:palette.destructive,fontSize:12,marginTop:-5}}>{optionError}</AppText>:null}
        <Pressable onPress={addOption} disabled={draft.options.length>=6} style={({pressed})=>[s.addButton,{borderColor:palette.border,opacity:draft.options.length>=6?.4:pressed?.65:1,flexDirection:isRTL?'row-reverse':'row'}]}><Feather name="plus" size={17} color={palette.primary}/><AppText style={{color:palette.primary,fontSize:13}} bold>{t('addOption')}</AppText></Pressable>
      </View>
    </KeyboardAwareScrollViewCompat>
    <View style={[s.footer,{backgroundColor:palette.background,paddingBottom:insets.bottom+12}]}><PrimaryButton label={t('next')} onPress={next} icon={isRTL?'arrow-left':'arrow-right'}/></View>
  </View>;
}
const s=StyleSheet.create({root:{flex:1},intro:{marginBottom:24},stepBadge:{paddingHorizontal:10,paddingVertical:5,borderRadius:9,marginBottom:12},stepText:{fontSize:11},heading:{fontSize:23,marginBottom:7},subheading:{fontSize:13,lineHeight:22},section:{marginTop:8},sectionHeader:{alignItems:'center',justifyContent:'space-between',marginBottom:14},sectionTitle:{fontSize:18,marginBottom:4},sectionHint:{fontSize:12},countBadge:{paddingHorizontal:9,paddingVertical:6,borderRadius:9},countText:{fontSize:11},optionRow:{alignItems:'center',gap:8,marginBottom:2},number:{width:28,height:28,borderRadius:10,alignItems:'center',justifyContent:'center'},numberText:{fontSize:12},deleteButton:{width:26,alignItems:'center',justifyContent:'center'},addButton:{height:46,borderWidth:1,borderStyle:'dashed',borderRadius:14,alignItems:'center',justifyContent:'center',gap:7,marginTop:4},footer:{position:'absolute',bottom:0,left:0,right:0,paddingHorizontal:20,paddingTop:10}});
