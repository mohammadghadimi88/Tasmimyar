import { Feather } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React from 'react';
import { Alert,Pressable,StyleSheet,View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppText,Screen } from '@/components/ui';
import { useDecisionStore } from '@/context/DecisionContext';
import { useLanguage } from '@/context/LanguageContext';
import { calculateResults,formatDate } from '@/utils/decision';

export default function HistoryScreen(){
 const router=useRouter();const insets=useSafeAreaInsets();const {decisions,palette,openDecision,deleteDecision}=useDecisionStore();const {t,language,isRTL}=useLanguage();
 const confirmDelete=(id:string)=>Alert.alert(t('deleteDecision'),t('deleteConfirm'),[{text:t('cancel'),style:'cancel'},{text:t('delete'),style:'destructive',onPress:()=>deleteDecision(id)}]);
 return <Screen scroll contentStyle={{paddingTop:insets.top+12,paddingBottom:insets.bottom+28}}>
  <View style={[s.header,{flexDirection:isRTL?'row-reverse':'row'}]}><View style={{alignItems:isRTL?'flex-end':'flex-start'}}><AppText muted style={s.overline}>{t('archive')}</AppText><AppText style={s.title} bold>{t('myDecisions')}</AppText></View><View style={[s.headerIcon,{backgroundColor:palette.secondary}]}><Feather name="archive" size={21} color={palette.secondaryForeground}/></View></View>
  <AppText muted style={s.subtitle}>{t('archiveBody')}</AppText>
  {!decisions.length?<View style={[s.empty,{backgroundColor:palette.card,borderColor:palette.border}]}><View style={[s.emptyIcon,{backgroundColor:palette.secondary}]}><Feather name="inbox" size={24} color={palette.secondaryForeground}/></View><AppText style={s.emptyTitle} bold>{t('archiveEmpty')}</AppText><AppText muted style={s.emptyBody}>{t('archiveEmptyBody')}</AppText></View>:
  <View style={s.list}>{decisions.map(decision=>{const winner=calculateResults(decision)[0];return <Pressable key={decision.id} onPress={()=>{openDecision(decision);router.push({pathname:'/result',params:{id:decision.id}})}} style={({pressed})=>[s.card,{backgroundColor:palette.card,borderColor:palette.border,opacity:pressed?.76:1}]}>
   <View style={[s.cardTop,{flexDirection:isRTL?'row-reverse':'row'}]}><View style={[s.cardIcon,{backgroundColor:palette.accent}]}><Feather name="bar-chart-2" size={18} color={palette.accentForeground}/></View><View style={[s.cardCopy,{alignItems:isRTL?'flex-end':'flex-start'}]}><AppText style={s.cardTitle} bold numberOfLines={1}>{decision.title}</AppText><AppText muted style={s.cardDate}>{formatDate(decision.updatedAt,language)}</AppText></View><Pressable onPress={()=>confirmDelete(decision.id)} hitSlop={10} style={s.delete}><Feather name="more-horizontal" size={19} color={palette.mutedForeground}/></Pressable></View>
   <View style={[s.divider,{backgroundColor:palette.border}]}/><View style={[s.bottom,{flexDirection:isRTL?'row-reverse':'row'}]}><View style={[s.meta,{flexDirection:isRTL?'row-reverse':'row'}]}><Feather name="layers" size={14} color={palette.mutedForeground}/><AppText muted style={s.metaText}>{decision.options.length} {t('optionsCount')}</AppText></View><View style={[s.meta,{flexDirection:isRTL?'row-reverse':'row',maxWidth:'55%'}]}><Feather name="trending-up" size={14} color={palette.success}/><AppText style={[s.metaText,{color:palette.success}]} numberOfLines={1}>{winner?.option.label??t('resultReady')}</AppText></View></View>
  </Pressable>})}</View>}
 </Screen>;
}
const s=StyleSheet.create({header:{justifyContent:'space-between',alignItems:'center',marginBottom:7},overline:{fontSize:12,marginBottom:3},title:{fontSize:24},headerIcon:{width:46,height:46,borderRadius:16,alignItems:'center',justifyContent:'center'},subtitle:{fontSize:12,lineHeight:21,marginBottom:22},list:{gap:12},card:{borderWidth:1,borderRadius:20,padding:14},cardTop:{alignItems:'center',gap:10},cardIcon:{width:40,height:40,borderRadius:13,alignItems:'center',justifyContent:'center'},cardCopy:{flex:1},cardTitle:{width:'100%',fontSize:14,marginBottom:4},cardDate:{fontSize:11},delete:{width:30,alignItems:'center'},divider:{height:1,marginVertical:14},bottom:{alignItems:'center',justifyContent:'space-between'},meta:{alignItems:'center',gap:5},metaText:{fontSize:11},empty:{borderWidth:1,borderRadius:20,alignItems:'center',padding:24,marginTop:18},emptyIcon:{width:52,height:52,borderRadius:18,alignItems:'center',justifyContent:'center',marginBottom:11},emptyTitle:{fontSize:16,marginBottom:6},emptyBody:{fontSize:12,textAlign:'center',lineHeight:20}});
