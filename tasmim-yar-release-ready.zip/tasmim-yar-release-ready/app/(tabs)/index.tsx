import { Feather } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppText, PrimaryButton, Screen, SectionTitle } from '@/components/ui';
import { useDecisionStore } from '@/context/DecisionContext';
import { useLanguage } from '@/context/LanguageContext';
import { calculateResults, formatDate } from '@/utils/decision';

export default function HomeScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { decisions, palette, startNewDecision, openDecision } = useDecisionStore();
  const { t, language, isRTL } = useLanguage();
  const recentDecisions = decisions.slice(0, 3);
  const createDecision = () => { startNewDecision(); router.push('/create'); };

  return (
    <Screen scroll contentStyle={{ paddingTop: insets.top + 12, paddingBottom: insets.bottom + 28 }}>
      <View style={[s.header, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
        <View style={[s.brandRow, { flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
          <View style={[s.brandMark, { backgroundColor: palette.primary }]}><Feather name="check" size={20} color={palette.primaryForeground} /></View>
          <View style={{ alignItems: isRTL ? 'flex-end' : 'flex-start' }}>
            <AppText style={s.brandName} bold>{t('appName')}</AppText>
            <AppText muted style={s.brandHint}>{t('appTagline')}</AppText>
          </View>
        </View>
        <View style={[s.statusDot, { backgroundColor: palette.success }]} />
      </View>

      <View style={[s.hero, { backgroundColor: palette.primary, direction: isRTL ? 'rtl' : 'ltr' }]}>
        <AppText style={s.heroEyebrow}>{t('homeEyebrow')}</AppText>
        <AppText style={s.heroTitle} bold>{t('homeTitle')}</AppText>
        <AppText style={s.heroBody}>{t('homeBody')}</AppText>
        <Pressable onPress={createDecision} style={({ pressed }) => [s.heroButton, { opacity: pressed ? 0.8 : 1 }]}>
          <Feather name="plus" size={18} color={palette.primary} />
          <AppText style={[s.heroButtonText, { color: palette.primary }]} bold>{t('newDecision')}</AppText>
        </Pressable>
      </View>

      <SectionTitle
        title={t('recentDecisions')}
        caption={decisions.length ? `${decisions.length} ${t('savedDecisions')}` : undefined}
        action={decisions.length > 3 ? t('viewAll') : undefined}
        onAction={() => router.push('/history')}
      />

      {recentDecisions.length ? (
        <View style={s.list}>
          {recentDecisions.map((decision) => {
            const winner = calculateResults(decision)[0];
            return (
              <Pressable key={decision.id} onPress={() => { openDecision(decision); router.push({ pathname: '/result', params: { id: decision.id } }); }}
                style={({ pressed }) => [s.decisionCard, { backgroundColor: palette.card, borderColor: palette.border, opacity: pressed ? 0.78 : 1, flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
                <View style={s.cardIcon}><Feather name="bar-chart-2" size={19} color={palette.secondaryForeground} /></View>
                <View style={[s.cardContent, { alignItems: isRTL ? 'flex-end' : 'flex-start' }]}>
                  <AppText style={s.cardTitle} bold numberOfLines={1}>{decision.title}</AppText>
                  <View style={s.cardMeta}>
                    <AppText muted style={s.metaText}>{formatDate(decision.updatedAt, language)}</AppText>
                    <View style={[s.dot, { backgroundColor: palette.border }]} />
                    <AppText muted style={s.metaText}>{decision.options.length} {t('optionsCount')}</AppText>
                  </View>
                  <View style={[s.resultPill, { backgroundColor: palette.accent, alignSelf: isRTL ? 'flex-end' : 'flex-start', flexDirection: isRTL ? 'row-reverse' : 'row' }]}>
                    <Feather name="trending-up" size={13} color={palette.accentForeground} />
                    <AppText style={[s.pillText, { color: palette.accentForeground }]} numberOfLines={1}>{winner?.option.label || t('resultReady')}</AppText>
                  </View>
                </View>
                <View style={[s.cardArrow, { transform: [{ scaleX: isRTL ? 1 : -1 }] }]}><Feather name="chevron-left" size={18} color={palette.mutedForeground} /></View>
              </Pressable>
            );
          })}
        </View>
      ) : (
        <View style={[s.emptyCard, { backgroundColor: palette.card, borderColor: palette.border }]}>
          <View style={[s.emptyIcon, { backgroundColor: palette.secondary }]}><Feather name="compass" size={24} color={palette.secondaryForeground} /></View>
          <AppText style={s.emptyTitle} bold>{t('noDecision')}</AppText>
          <AppText muted style={s.emptyText}>{t('noDecisionBody')}</AppText>
          <PrimaryButton label={t('firstDecision')} onPress={createDecision} icon="plus" />
        </View>
      )}
    </Screen>
  );
}

const s = StyleSheet.create({
  header:{alignItems:'center',justifyContent:'space-between',marginBottom:22},
  brandRow:{alignItems:'center',gap:10}, brandMark:{width:42,height:42,borderRadius:14,alignItems:'center',justifyContent:'center'},
  brandName:{fontSize:20,lineHeight:26},brandHint:{fontSize:11,marginTop:1},statusDot:{width:9,height:9,borderRadius:5},
  hero:{borderRadius:25,padding:22,minHeight:242,overflow:'hidden',marginBottom:28},heroEyebrow:{color:'rgba(255,255,255,0.72)',fontSize:12,marginBottom:12},
  heroTitle:{color:'#fff',fontSize:22,lineHeight:33,marginBottom:8},heroBody:{color:'rgba(255,255,255,0.76)',fontSize:13,lineHeight:23,maxWidth:300,marginBottom:18},
  heroButton:{alignSelf:'flex-start',minHeight:43,borderRadius:14,backgroundColor:'#fff',paddingHorizontal:15,flexDirection:'row',alignItems:'center',gap:6},
  heroButtonText:{fontSize:13},list:{gap:12},decisionCard:{minHeight:116,borderWidth:1,borderRadius:20,padding:14,alignItems:'center',gap:12},
  cardContent:{flex:1},cardIcon:{width:42,height:42,borderRadius:14,alignItems:'center',justifyContent:'center',backgroundColor:'#E8EDF8'},
  cardArrow:{width:24,alignItems:'center'},cardTitle:{width:'100%',fontSize:15,marginBottom:7},cardMeta:{flexDirection:'row',alignItems:'center',gap:7,marginBottom:9},
  metaText:{fontSize:11},dot:{width:3,height:3,borderRadius:2},resultPill:{alignItems:'center',gap:5,paddingHorizontal:8,paddingVertical:4,borderRadius:8,maxWidth:'100%'},
  pillText:{fontSize:10},emptyCard:{borderWidth:1,borderRadius:22,padding:22,alignItems:'center',gap:10},emptyIcon:{width:54,height:54,borderRadius:18,alignItems:'center',justifyContent:'center',marginBottom:4},
  emptyTitle:{fontSize:16},emptyText:{fontSize:13,textAlign:'center',lineHeight:22,marginBottom:8},
});
