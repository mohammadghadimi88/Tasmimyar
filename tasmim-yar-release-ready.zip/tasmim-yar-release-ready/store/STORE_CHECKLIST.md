# Store release checklist

## Android / Google Play
- App name: DecisionYar
- Short description: Make clearer decisions with weighted criteria.
- Full description: DecisionYar helps you structure everyday decisions. Add options, define what matters, assign importance, score each option from 1 to 10, and review the weighted result. The app is designed to reflect your own criteria and scores rather than make the decision for you.
- Category suggestion: Productivity
- Current app behavior: no login, no ads, no payments, local decision storage.
- Upload production `.aab`, not `.apk`.

## iOS / App Store
- Name: DecisionYar
- Subtitle: Make clearer decisions
- Keywords: decision, decision maker, decision matrix, compare, criteria, choices
- Description: DecisionYar helps you make structured decisions by comparing options against criteria that matter to you. Set the importance of each criterion, score your options, and review a weighted result. Your criteria and scores stay under your control; the app does not make the final decision for you.

## Privacy
Host `privacy-policy.html` at a stable public HTTPS URL and use that URL in Google Play/App Store Connect.

## Screenshots
After installing the preview APK, capture real-device screenshots of:
1. Home
2. New Decision
3. Criteria
4. Scoring
5. Results
6. Settings / Language

Use English screenshots for the English store listing and Persian screenshots for the Persian listing.
